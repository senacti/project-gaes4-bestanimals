var infoButtons = document.getElementsByClassName('info-button');
const launcAlert=document.getElementById("alerta-form");
const closeButton=document.getElementById("cerrahte");
  closeButton.addEventListener('click', function(){
      launcAlert.classList.remove("ver");
  
      
  })
  
  