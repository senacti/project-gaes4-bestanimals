
function redirjirAddMascota() {
    document.location.href=urlAñadirMascota;
}