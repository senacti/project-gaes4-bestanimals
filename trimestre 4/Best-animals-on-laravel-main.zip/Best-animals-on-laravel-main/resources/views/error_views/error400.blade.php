<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>error_400</title>
    <link rel="stylesheet" href="{{asset('CSS/style12.css')}}">
</head>
<body>
    <div class="main_contenedor">
        <div class="mitad_gato">
            <img class="cat_size" src="img/her-removebg-preview.png" alt="not found page">
        </div>
        <div class="mitad_texto">
            <div class="content"><div class="mitad_number"><p class="a">404</p></div>
        <div class="mitad_info"><p class="b">Page Not Found</p></div>
        
        </div>
        </div>
    </div>
    
</body>
</html>