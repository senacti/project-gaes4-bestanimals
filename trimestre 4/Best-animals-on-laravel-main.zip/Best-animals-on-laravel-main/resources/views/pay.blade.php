<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar carro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="stylePay.css">
</head>
<body>
   <header class="container-header">
<a class="put-logo" href="">
    <img class="image-logo" src="best animal2-01 (1).png" alt="">
</a>
   </header> 
   <main class="main-container">
    <div class="container-volver">
        <a class="link" href=""><-Volver</a>
       
    </div>
    <div class="container-titulo">
        <div class="contenedor-img">
            <div class="put-img"><i class="bi bi-cart3"></i></div>
            <div class="descripcion"></div>
        </div>
    </div>
   </main>
   <footer class="footer-container"></footer>
</body>
</html>