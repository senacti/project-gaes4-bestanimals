<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/style19.css') }}">
    <title>incio</title>
</head>
<body>
    <div class="contenedor-header">
<a class="content" href="{{route('index')}}">
    <img class="logo" src="img/best animal2-01 (1).png" alt="logo">
</a>
    </div>

    <div class="middle-contenedor">
<div class="middle-row">
    <div class="txt-1">bienvenido, ten el mejor trato en </div>
    <div class="contenedor-huellas">
        
    </div>
</div>
<div class="middle-row2">
<div class="central-txt">BEST ANIMALS</div>

</div>
<div class="middle-row3">
    <div class="txt-3">especialistas en el cuidado de mascotas</div>
    <div class="contenedor-mascotas"><img class="mascotas" src="img/f8e236c1-01c0-4e15-a6e8-76f25717867d-removebg-preview.png" alt="mascotas"></div>
</div>
    </div>
    <footer class="footer-contenedor">
<div class="mitad-1">
<div class="container-gps">
<a class="put-gps" href="">
<img class="imagen" src="img/gpsicon_preview_rev_1.png" alt="">
</a>
</div>
<div class="container-text">
    <div class="internal-text">¡te esperamos!</div>
    <div class="internal-text1">BEST ANIMALS</div>
    <div class="internal-text2">como llegar a..</div>
</div>
<div class="sedes">
<div class="part">VETERINARIA CHIA <div class="linea-2"></div></div>
<div class="part-2">VETERINARIA ZIPAQUIRA</div>

</div>

</div>
<div class="linea"></div>
<div class="mitad-2">
<div class="container-blackberry">
<a class="put-phone" href="">
<img class="imy" src="img/blackberry-removebg-preview.png" alt="telefono">

</a>

</div>
<div class="comms-container">
<div class="comms-content">
comunicate! <br> TE RESPONDEMOS EN MINUTOS

</div>

</div>
<div class="container-numeros">
<div class="divi-1">3229426297 <div class="linea-3"></div></div>
<div class="divi-2">3163920712</div>
</div>
</div>

    </footer>
    
</body>
</html>