<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta Veterinaria</title>
    <link rel="stylesheet" href="{{ asset('css/style9.css') }}">
</head>
<body>
    <header class="contenedor1">
        
        <div class="contenido">
        <nav class="nav_logo" >
        <a href="{{route('index')}}"><img class="img_logo" src="img/best animal2-01 (1).png" alt="logo">
        </a>
        </nav>
        
        </div>
    </header>
    <div class="contenedor2">
        <div class="contf">
            <div class="huellas"></div>
        </div>
        <div class="contletras">
            <p class="maintitle">CONSULTA VETERINARIA</p>
        </div>
        <div class="contf"><div class="huellas">

        </div></div>
    </div>
    <div class="espacio">


    </div>
<nav class="contenedor3">
<div class="box1"><header class="tituloo"><a class="dentro" href="{{route('loginCita')}}">Consulta Médica</a></header> <div class="contimages"> <a class="photosurl" href="{{route('loginCita')}}"><img class="kaw" src="img/COnsulta_medica.PNG" alt="consulta"></a></div>        </div>
<div class="box1"> <header class="tituloo"><a class="dentro" href="{{route('loginCita')}}">Vacunacion y <br> Desparacitacion</a></header><div class="contimages"><a class="photosurl" href="{{route('loginCita')}}"><img class="kaw" src="img/cat_vacuna.PNG" alt="vacunacion"></a></div>         </div>
<div class="box1"><header class="tituloo"><a class="dentro" href="{{route('loginCita')}}">Cirujia Y Hospital</a></header> <div class="contimages"><a class="photosurl" href="{{route('loginCita')}}"><img class="kaw" src="img/cirujia_hospital.PNG" alt="cirujia"></a></div>         </div>
<div class="box1"> <header class="tituloo"><a class="dentro" href="{{route('loginCita')}}">Profilaxis</a></header> <div class="contimages"><a class="photosurl" href="{{route('loginCita')}}"><img class="kaw" src="img/profi.PNG" alt="cirujia"></a></div>      </div>



</nav>

</body>
</html>
