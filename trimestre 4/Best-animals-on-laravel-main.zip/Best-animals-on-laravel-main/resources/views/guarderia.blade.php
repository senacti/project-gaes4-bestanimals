<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guarderia</title>
    <link rel="stylesheet" href="CSS/style17.css">
</head>
<body>
    <div class="general-container">
        <header class="contenedor1">
        
            <div class="contenido">
            <nav class="nav_logo" >
            <a href="{{route('index')}}"><img class="img_logo" src="img/best animal2-01 (1).png" alt="logo">
            </a>
            </nav>
            
            </div>
        </header>
        <div class="contenedor2">
            
            <div class="contletras">
              <div class="mitad-title">GUARDERIA</div> 
               <div class="cont-img"><img class="avi" src="img/bb5fe413-be69-489e-9f1c-95017d60654d-transformed_preview_rev_1.png" alt=""></div>
            </div>
            
        </div>
        <div class="subtitle-contenedor">
<div class="contenido-subtitulo">
    ¿NO TIENES CON QUIEN DEJAR A TU MASCOTA?
</div>
        </div>
        <div class="container-after-subti">
<div class="mitad-texto"><div class="put-text">No te preocupes nosotros nos encargamos, en nuestra guardería podrás contar con,  transporte puerta a puerta, encargados de que tu mascota siga su rutina diaria, tu escoges el tiempo que requiere para así brindarle un rato acogedor </div></div>
<div class="mitad-image">
    <a class="cont-link" href="{{route('loginCita')}}"><img class="form-img" src="img/CASITA-removebg-preview.png" alt="casa"></a> <a class="description" href="{{route('loginCita')}}">HAZ CLICK PARA CONTACTARNOS</a>
</div>

        </div>




    </div>
</body>
</html>