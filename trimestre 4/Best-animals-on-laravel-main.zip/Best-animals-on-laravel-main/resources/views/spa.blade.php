<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/style8.css') }}">
    <title>Spa</title>
</head>
<body>
    <header class="contenedor1">
        
        <div class="contenido">
        <nav class="nav_logo" >
        <a href="{{route('index')}}"><img class="img_logo" src="img/best animal2-01 (1).png" alt="logo">
        </a>
        </nav>
        
        </div>
            </header>
            <div class="contenedor2">
                <div class="content"><h1 class="tittle">PELUQUERIA Y BAÑO</h1></div>
            </div>
            <div class="bubbles">
                <div class="burbus">
                    <img class="burbus1" src="img/minburbu.PNG" alt="burbujas">
                </div>
                <div class="mensaje">
                    <header class="titulo"><h1 class="mayus">TARDE DE SPA</h1></header>
                    <div class="texts"><p class="desc">si quieres una tarde relajante para tu mascota, contactanos, ofrecemos baño completo y medicado, corte higiénico, limpieza de oídos y corte de uñas.</p>  </div>
                </div>
                <div class="espacio"></div>
                <div class="contdog"> <img class="perro" src="img/Mi proyecto (2).png" alt="pug"></div>
            </div>
           
    
</body>
</html>