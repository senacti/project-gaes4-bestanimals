<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registro satisfactorio</title>
    <link rel="stylesheet" href="{{ asset('css/style18.css') }}">
</head>
<body>
    <div class="contenedor-general">
<div class="contenedor-header">
<header class="contenido-header">
<img class="img1" src="img/best animal2-01 (1).png" alt="">

</header>

</div>
<div class="middle-contenedor">
<div class="contenido-medio">
<div class="main-text">TE HAS REGISTRADO SATISFACTORIAMENTE!   </div>
<div class="sub-text">Gracias por registrarse con nosotros, puedes iniciar sesion para mantenerte al tanto de las novedades o regresar a la pagina de inicio si lo deseas.    </div>
<nav class="botones"><a class="button" href="{{route('index')}}">IR A INICIO</a> <a class="button" href="{{route('login')}}">IR A INICIAR SESION</a>                         </nav>
</div>


</div>
<footer class="contendor-footer">
    2022 Clínica Veterinaria Best Animals, todos los derechos reservados



</footer>
    </div>
    
</body>
</html>