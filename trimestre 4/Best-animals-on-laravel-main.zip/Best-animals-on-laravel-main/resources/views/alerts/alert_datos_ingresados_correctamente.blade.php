<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style27.css">
    <title>alert</title>
</head>
<body>
    
    <div class="container-alerta" id="alert-disponible" >
    
        <div class="alerta">
          <div class="contenido-alerta">
        <div class="alert-image">
          <img class="perro-alerta" src="img/gato-imagen-animada-0338.gif" alt="perro">
        </div>
        <div class="text-alert">
          <p>{{session('success')}}</p>
        </div>
        
          </div>
        </div>
        
          </div>
    
</body>
</html>