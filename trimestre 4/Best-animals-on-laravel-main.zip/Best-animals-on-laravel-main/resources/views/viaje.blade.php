<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/style16.css') }}">
    <title>viajes</title>
</head>
<body>
    <div class="general-container">
        <header class="contenedor1">
        
            <div class="contenido">
            <nav class="nav_logo" >
            <a href="{{route('index')}}"><img class="img_logo" src="img/best animal2-01 (1).png" alt="logo">
            </a>
            </nav>
            
            </div>
        </header>
        <div class="contenedor2">
            
            <div class="contletras">
              <div class="mitad-title">CERTIFICADOS PARA VIAJE</div> 
               <div class="cont-img"><img class="avi" src="img/Boton_avion-removebg-preview.png" alt=""></div>
            </div>
            
        </div>
        <div class="subtitle-contenedor">
<div class="contenido-subtitulo">
    ¿QUIERES VIAJAR CON TU MASCOTA?
</div>
        </div>
        <div class="container-after-subti">
<div class="mitad-texto"><div class="put-text">No te preocupes nosotros nos encargamos realizando todos los trámites, chequeos y certificaciones necesarias para el viaje nacional o internacional de tu mascota.
    también aseguramos que tu mascota tenga todos los requisitos veterinarios para viajar como,    vacunas o refuerzo de vacunas, serología</div></div>
<div class="mitad-image">
    <a class="cont-link" href="{{route('loginCita')}}"><img class="form-img" src="img/former-transformed-removebg-preview.png" alt="formulario"></a> <a class="description" href="{{route('loginCita')}}">HAZ CLICK PARA CONTACTARNOS</a>
</div>

        </div>




    </div>
    
</body>
</html>