<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mascotas</title>
    <link rel="stylesheet" href="{{ asset('css/style4.css') }}">
</head>
<body>
    <div class="contentheader">
<a class="logo" href="{{route('index')}}">
<img class="mencion" src="img/best animal2-01 (1).png" alt="logo">


</a>


    </div>
    <div class="maincontainermiddle">
        <div class="contenido1">
         <header class="tittle"><p class="internal_text">CONOCE UN POCO DE LA <br> FAMILIA BEST ANIMALS</p></header>
<div class="texto_centro"><p class="texti"> En Best Animals  Contamos con un equipo de trabajo altamente calificado, mas de 18 años de experiencia, con la disposición de dar dosis diarias de amor  a tus mascotas contamos con equipos tecnológicos de ultima generación para procedimientos y tratamientos efectivos y brindamos a tus mascotas sus mejores momentos en nuestras manos</p></div>
<div class="contener"><div class="contener1"><p class="blue">siempre velando por <br> la salud y el bienestar <br> de tu mascota</p></div> <div class="contener2"><img class="cora" src="img/corzon-removebg-preview.png" alt=""></div>       </div>


        </div>
        <div class="contenido2">
            <header class="logito">
                <img class="redi" src="img/best animal2-01 (1).png" alt="">


                
            </header>
            <div class="contenedorimagenes1">

                <div class="img1">
                    <img class="best1" src="img/besto1.PNG" alt="img1">    </div>
       <div class="img2">   
<img class="best2" src="img/best2.PNG" alt="img2">

       </div>
     
            </div>
            <div class="contenedorimagenes2">
                <div class="img3">    
<img class="best3" src="img/best3.PNG" alt="img3">

                </div>
                <div class="img4">
                <img class="cora" src="img/deco.PNG" alt="corazao">    
                </div>


            </div>


        </div>





    </div>

    <div class="pie">
<footer class="piess">
<div class="container_huellas"><img class="orange_huellas" src="img/orange_huellas-removebg-preview.png" alt="huellas"></div>
    <div class="container_dog"><img class="canva_perro" src="img/canva_perro-removebg-preview.png" alt=""> </div>
    <div class="container_huellas"><img class="orange_huellas" src="img/orange_huellas-removebg-preview.png" alt="huellas"></div>



</footer>

    </div>
</body>
</html>