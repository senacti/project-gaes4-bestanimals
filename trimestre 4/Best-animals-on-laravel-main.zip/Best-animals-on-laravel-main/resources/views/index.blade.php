<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Animals</title>
    <link rel="stylesheet" href="{{ asset('css/styleremastered.css') }}">
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/styleremastered.css?v2.26">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <title>Landing page</title>
</head>
<body>
    <header class="contenedor_flex">
     
<nav class="contenedor_logo"> <img class="perro" src="img/best animal2-01 (1).png" alt="logo"></nav>

<nav class="main_container_botones"> <div class="contedor_botones"> <a class="put_botones" href="{{route('inicio')}}"><img class="tamaño" src="img/inicio buttton.png" alt="inicio">   </a>
<a class="indices" href="{{route('inicio')}}">INICIO</a></div>
<div class="contedor_botones">
<a class="put_botones" href="{{route('servicios')}}"> <img class="tamaño" src="img/boton 2.jpg" alt="servicios"></a>
<a class="indices" href="{{route('servicios')}}">SERVICIOS</a>

</div>
<div class="contedor_botones">
    <a class="put_botones" href="{{route('tienda')}}"><img class="tamaño" src="img/boton 3.png" alt="services"></a>
    <a class="indices" href="{{route('tienda')}}">TIENDA ONLINE</a>

</div>
<div class="contedor_botones">
    <a class="put_botones" href=""><img class="tamaño" src="img/añañin.png" alt="blog"></a>
<a class="indices" href="">BLOG</a>
</div>
<div class="contedor_botones">
    <a class="put_botones" href="{{route('login')}}"><img class="tamaño" src="img/perf.jpg" alt="session"></a>
    <a class="indices" href="{{route('login')}}">INICAR SESION</a>

</div>
</nav>
</header>

    <div class="middle_contenedor">
        <div class="primera_mitad">
<div class="titulo">CLINICA VETERINARIA <br>
    BEST ANIMALS</div>
<div class="segunda_mitad">
<a class="boton_mascotas" href="{{route('info')}}"><p id="masc">MASCOTAS <i class="bi bi-arrow-right"></i></p>  </a> 


</div>


        </div>
        <div class="mitad_perro">
<img class="dog" src="img/perro.jpeg" alt="dog">

        </div>

    </div>

    <footer class="complete">
<div class="almacenar_redes">
<a class="put_red" href=""> <img src="img/maybe.png" class="cti" alt="instagram"></a>
<a class="put_red" href=""><img src="img/facebook-xxl.png" class="cti1" alt="facebook"></a>
<a class="put_red" href=""><img src="img/whatsapp-xxl.png" class="cti1" alt="whatsapp"></a>

</div>
<div class="contenedor_copy">
    2022 Clínica Veterinaria Best Animals, todos los derechos reservados
    
</div>

<footer>
    
    
</body>
</html>
</body>
</html>
